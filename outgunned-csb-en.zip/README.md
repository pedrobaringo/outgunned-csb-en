# Outgunned CSB EN

You'll need to have the Custom System Builder installed ( https://foundryvtt.com/packages/custom-system-builder ) that needs the following module https://foundryvtt.com/packages/_chatcommands

To install the Outgunned Module you have to go to Add-On Modules and install it using this Manifest: https://github.com/pedrobaringo/outgunned-csb-en/releases/latest/download/module.json

Here you have a video with instructions on how to use the module:

[![Video del tutorial](http://img.youtube.com/vi/SXJ3MpSNiog/0.jpg)](http://www.youtube.com/watch?v=SXJ3MpSNiog "Foundry Tutorial-Outgunned")
